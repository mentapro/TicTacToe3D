namespace Zenject.Tests.TickableManagers
{
        public class NestedTickableManagerHolder
        {
            [Inject] public TickableManager TickManager;
        }
}